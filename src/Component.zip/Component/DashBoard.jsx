import React from 'react';

const DashBoard = () => {
    return (
        <div>
            <h2>this is the Dashboard</h2>
        </div>
    );
};

export default DashBoard;