import React from 'react';
import SearchPage from '../SearchPage/SearchPage.jsx'
const MainPage = () => {
    return (
        <div>
         <SearchPage />
        </div>
    );
};

export default MainPage;